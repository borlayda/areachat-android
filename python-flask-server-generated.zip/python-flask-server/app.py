#!/usr/bin/env python3

import connexion

if __name__ == '__main__':
    app = connexion.App(__name__, specification_dir='./swagger/')
    app.add_api('swagger.yaml', arguments={'title': 'Talk with others in your area, with the Areachat application.\nThe application uses this API for saving information, or getting\ndata about other users.\n'})
    app.run(port=8080)
