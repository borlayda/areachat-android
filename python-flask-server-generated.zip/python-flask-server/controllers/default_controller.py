
def message_get(username) -> str:
    return 'do some magic!'

def message_post(_from, to, message) -> str:
    return 'do some magic!'

def position_get(longitude, latitude) -> str:
    return 'do some magic!'

def position_post(username, longitude, latitude) -> str:
    return 'do some magic!'

def login_user_post(username, password) -> str:
    return 'do some magic!'

def logout_user_post(username) -> str:
    return 'do some magic!'

def register_user_post(username, password, email, gender) -> str:
    return 'do some magic!'
